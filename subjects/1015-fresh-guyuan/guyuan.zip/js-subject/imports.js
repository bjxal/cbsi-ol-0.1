
require('core');
require('templates');
require('popup');
require('PageSlider');
require('weixin');

require('core');
require('PageSlider');
require('templates');
require('weixin');

require('core');
require('templates');
require('PageSlider');
require('weixin');

window['Tpl'] = {
    page1:require('!tpl:../tpl-subject/page1')
    ,page3:require('!tpl:../tpl-subject/page3')
};
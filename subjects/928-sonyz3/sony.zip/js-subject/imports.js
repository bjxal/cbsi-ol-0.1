
require('core');
require('templates');
require('PageSlider');
require('weixin');
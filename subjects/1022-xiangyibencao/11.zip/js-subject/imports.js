
require('core');
require('gravity');
require('templates');
require('popup');
require('PageSlider');
require('weixin');